import subprocess
import re
import json
import os
import time

NETWORK = "192.168.1.0/24"
FILE = "known_devices.json"

def scan():
    print("\n[*] Scanning network...")
    result = subprocess.run(
        ["nmap", "-sn", NETWORK],
        capture_output=True, text=True
    )

    devices = re.findall(
        r"Nmap scan report for .*?(\d+\.\d+\.\d+\.\d+)",
        result.stdout
    )

    devices = sorted(set(devices) - {"192.168.1.1"})

    old = set()
    if os.path.exists(FILE):
        with open(FILE) as f:
            old = set(json.load(f))

    new = set(devices) - old

    print("\nWIFI SCANNER PRO V3")
    print("=" * 35)

    for ip in devices:
        print("[+] ", ip)

    if new:
        print("\n[!] NEW DEVICES DETECTED!")
        for ip in new:
            print("[NEW] ", ip)
    else:
        print("\nNo new devices detected.")

    with open(FILE, "w") as f:
        json.dump(sorted(old | set(devices)), f)

    print("\nTotal devices:", len(devices))

while True:
    scan()
    choice = input("\n1 Scan Again\n2 Exit\nChoice: ")
    if choice == "2":
        break
